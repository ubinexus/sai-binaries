/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saischedulergroupextensions.h
 *
 * @brief   This module defines SAI QOS Scheduler Group interface extensions
 */

#ifndef __SAISCHEDULERGROUPEXTENSIONS_H_
#define __SAISCHEDULERGROUPEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Enum defining scheduler group attributes extensions.
 *
 * @flags free
 */
typedef enum _sai_scheduler_group_attr_extensions_t
{
    SAI_SCHEDULER_GROUP_ATTR_EXTENSIONS_RANGE_START = SAI_SCHEDULER_GROUP_ATTR_END,

    /**
     * @brief Scheduler group service id
     *
     * when set, this group is used for dedicate service
     * for example, Virtual Private LAN Service/Virtual Private Wire Service AC bridge port/Pseudo wire tunnel port, this service id should also be set in
     * Virtual Private LAN Service/Virtual Private Wire Service AC bridge port/Pseudo wire tunnel port, and queues for services
     *
     * when set to 0, it's a normal scheduler group
     *
     * @type sai_uint16_t
     * @flags CREATE_ONLY
     * @isvlan false
     * @default 0
     */
    SAI_SCHEDULER_GROUP_ATTR_SERVICE_ID = SAI_SCHEDULER_GROUP_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Scheduler group service id direction
     *
     * when set to 0, it's a ingress service scheduler group, when set to 1, it's a egress service scheduler group
     * valid when SAI_SCHEDULER_GROUP_ATTR_SERVICE_ID is not 0
     *
     * @type sai_uint16_t
     * @flags CREATE_ONLY
     * @isvlan false
     * @default 0
     */
    SAI_SCHEDULER_GROUP_ATTR_SERVICE_ID_DIRECTION,

    SAI_SCHEDULER_GROUP_ATTR_EXTENSIONS_RANGE_END

} sai_scheduler_group_attr_extensions_t;

#endif /** __SAISCHEDULERGROUPEXTENSIONS_H_ */
