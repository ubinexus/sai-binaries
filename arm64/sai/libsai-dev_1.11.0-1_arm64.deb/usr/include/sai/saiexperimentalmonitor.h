/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiexperimentalmonitor.h
 *
 * @brief   This module defines SAI MONITOR
 */

#if !defined (__SAIEXPERIMENTALMONITOR_H_)
#define __SAIEXPERIMENTALMONITOR_H_

#include <saitypes.h>

/**
 * @defgroup SAIMONITOR SAI - Monitor specific API definitions
 *
 * @{
 */

/**
 * @brief Attribute Id in create_monitor_buffer_monitor() and;
 * set_monitor_buffer_monitor_attribute();
 * remove_monitor_buffer_monitor();
 * get_monitor_buffer_monitor_attribute();
 */
typedef enum _sai_monitor_buffer_monitor_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_START = 0x00000000,

    /**
     * @brief Define the min threshold of microburst based on port
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE |CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_PORT = SAI_MONITOR_BUFFER_MONITOR_ATTR_START,

    /**
     * @brief Define the min threshold of microburst based on port(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_MB_PORT_MIN_THRESHOLD,

    /**
     * @brief Define the max threshold of microburst based on port(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_MB_PORT_MAX_THRESHOLD,

    /**
     * @brief Enable the ingress monitor  based on port, set the periodical monitor time. when a cycle ends and the notification is triggered.
     * The system can get the byte number of messages
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_INGRESS_PORT_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Enable the egress monitor  based on port, set the periodical monitor time. when a cycle ends and the notification is triggered.
     * The system can get the byte number of messages
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_EGRESS_PORT_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Record max unicast buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_EGRESS_PORT_UNICAST_WATERMARK,

    /**
     * @brief Record max multicast buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_EGRESS_PORT_MULTICAST_WATERMARK,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_EGRESS_PORT_TOTAL_WATERMARK,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_INGRESS_PORT_TOTAL_WATERMARK,

    /**
     * @brief End of attributes
     */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_END,

    /** Custom range base value */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_MONITOR_BUFFER_MONITOR_ATTR_CUSTOM_RANGE_END

} sai_monitor_buffer_monitor_attr_t;

/**
 * @brief Attribute Id in create_monitor_latency_monitor() and;
 * set_monitor_latency_monitor_attribute();
 * remove_monitor_latency_monitor();
 * get_monitor_latency_monitor_attribute();
 */
typedef enum _sai_monitor_latency_monitor_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_START = 0x00000000,

    /**
     * @brief Define the min threshold of microburst based on port
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE |CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_PORT = SAI_MONITOR_LATENCY_MONITOR_ATTR_START,

    /**
     * @brief Latency monitor over max threshold inform enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_OVER_MAX_THRESHOLD_INFORM_ENABLE,

    /**
     * @brief Log the packet to CPU when the count of latency range over the threshold, per port per level control,
     * there are 8 elements required in the array
     *
     * @type sai_u8_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_LEVEL_OVERTHRD_EVENT,

    /**
     * @brief Enable the latency monitor,set the periodical monitor time. when a cycle ends and the notification is triggered.
     * The system can get the byte number of messages
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Per level control, if one packet latency in the level, the packet will be discarded
     * there are 8 elements required in the array
     *
     * @type sai_u8_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_LEVEL_DISCARD,

    /**
     * @brief Record max time latency of each port(unit is Nanosecond), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_PORT_WATERMARK,

    /**
     * @brief End of attributes
     */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_END,

    /** Custom range base value */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_MONITOR_LATENCY_MONITOR_ATTR_CUSTOM_RANGE_END

} sai_monitor_latency_monitor_attr_t;

/**
 * @brief Attribute data for SAI MOX session type
 */
typedef enum _sai_monitor_mox_session_type_t
{
    /** Ingress */
    SAI_MONITOR_MOX_SESSION_TYPE_INGRESS,

    /** MMU */
    SAI_MONITOR_MOX_SESSION_TYPE_MMU,

    /** Egress */
    SAI_MONITOR_MOX_SESSION_TYPE_EGRESS,

} sai_monitor_mox_session_type_t;

/**
 * @brief Attribute data for SAI MOX session event type
 */
typedef enum _sai_monitor_mox_session_event_type_t
{
    /** Drop */
    SAI_MONITOR_MOX_SESSION_EVENT_TYPE_DROP,

    /** Burst */
    SAI_MONITOR_MOX_SESSION_EVENT_TYPE_BURST,

    /** Latency */
    SAI_MONITOR_MOX_SESSION_EVENT_TYPE_LATENCY,

} sai_monitor_mox_session_event_type_t;

/**
 * @brief Packet Forward Type
 */
typedef enum _sai_monitor_mox_session_packet_forward_type_t
{
    /** None Packet Forward Type */
    SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_NONE,

    /** Packet Forward Type of Layer 2 Unicast */
    SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_L2UC,

    /** Packet Forward Type of Layer 2 Mcast */
    SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_L2MC,

    /** Packet Forward Type of Unknown Layer 2 */
    SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_UNKNOWN_L2,

    /** Packet Forward Type of Layer 3 Unicast */
    SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_L3UC,

    /** Packet Forward Type of Layer 3 Mcast */
    SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_L3MC,

    /** Packet Forward Type of Broadcast */
    SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_BC

} sai_monitor_mox_session_packet_forward_type_t;

/**
 * @brief Discard Type
 */
typedef enum _sai_monitor_mox_session_discard_type_t
{
    /** None Discard Type */
    SAI_MONITOR_MOX_SESSION_DISCARD_TYPE_NONE,

    /** All Discard Type */
    SAI_MONITOR_MOX_SESSION_DISCARD_TYPE_ALL

} sai_monitor_mox_session_discard_type_t;

/**
 * @brief MOX session attribute IDs
 */
typedef enum _sai_monitor_mox_session_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_MONITOR_MOX_SESSION_ATTR_START = 0x00000000,

    /**
     * @brief MOX session flow field object
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_MONITOR_MOX_SESSION_FLOW_FIELD
     */
    SAI_MONITOR_MOX_SESSION_ATTR_FLOW_FIELD_OBJECT = SAI_MONITOR_MOX_SESSION_ATTR_START,

    /**
     * @brief MOX session type
     *
     * @type sai_monitor_mox_session_type_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_MONITOR_MOX_SESSION_ATTR_TYPE,

    /**
     * @brief MOX session event objects list
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MONITOR_MOX_SESSION_EVENT
     * @default empty
     */
    SAI_MONITOR_MOX_SESSION_ATTR_EVENT_OBJECTS_LIST,

    /**
     * @brief Packet Forward Type
     *
     * @type sai_monitor_mox_session_packet_forward_type_t
     * @flags CREATE_ONLY
     * @default SAI_MONITOR_MOX_SESSION_PACKET_FORWARD_TYPE_NONE
     */
    SAI_MONITOR_MOX_SESSION_ATTR_PACKET_FORWARD_TYPE,

    /**
     * @brief Discard Type
     *
     * @type sai_monitor_mox_session_discard_type_t
     * @flags CREATE_ONLY
     * @default SAI_MONITOR_MOX_SESSION_DISCARD_TYPE_NONE
     */
    SAI_MONITOR_MOX_SESSION_ATTR_DISCARD_TYPE,

    /**
     * @brief End of attributes
     */
    SAI_MONITOR_MOX_SESSION_ATTR_END,

    /** Custom range base value */
    SAI_MONITOR_MOX_SESSION_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_MONITOR_MOX_SESSION_ATTR_CUSTOM_RANGE_END

} sai_monitor_mox_session_attr_t;

/**
 * @brief MOX session flow field attribute IDs
 */
typedef enum _sai_monitor_mox_session_flow_field_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_START = 0x00000000,

    /**
     * @brief MOX session flow field port
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_PORT_ENABLE = SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_START,

    /**
     * @brief MOX session flow field source IPv4 address
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_SRC_IPV4_ENABLE,

    /**
     * @brief MOX session flow field destination IPv4 addresses
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_DST_IPV4_ENABLE,

    /**
     * @brief MOX session flow field source IPv6 address
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_SRC_IPV6_ENABLE,

    /**
     * @brief MOX session flow field destination IPv6 addresses
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_DST_IPV6_ENABLE,

    /**
     * @brief MOX session flow field IP protocol
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_IP_PROTOCOL_ENABLE,

    /**
     * @brief MOX session flow field l4 src port
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_L4_SRC_PORT_ENABLE,

    /**
     * @brief MOX session flow field l4 dst port
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_L4_DST_PORT_ENABLE,

    /**
     * @brief MOX session flow field virtual router ID
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_VIRTUAL_ROUTER_ID_ENABLE,

    /**
     * @brief MOX session flow field vlan id
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_VLAN_ID_ENABLE,

    /**
     * @brief MOX session flow field VNI
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_VNI_ENABLE,

    /**
     * @brief End of attributes
     */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_END,

    /** Custom range base value */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_MONITOR_MOX_SESSION_FLOW_FIELD_ATTR_CUSTOM_RANGE_END

} sai_monitor_mox_session_flow_field_attr_t;

/**
 * @brief MOX session event attribute IDs
 */
typedef enum _sai_monitor_mox_session_event_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_START = 0x00000000,

    /**
     * @brief MOX session event type
     *
     * @type sai_monitor_mox_session_event_type_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_TYPE = SAI_MONITOR_MOX_SESSION_EVENT_ATTR_START,

    /**
     * @brief MOX session event burst packet number threshold
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_MONITOR_MOX_SESSION_EVENT_ATTR_TYPE == SAI_MONITOR_MOX_SESSION_EVENT_TYPE_BURST
     */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_BURST_PACKET_NUM_THRESHOLD,

    /**
     * @brief MOX session event latency packet number threshold
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_MONITOR_MOX_SESSION_EVENT_ATTR_TYPE == SAI_MONITOR_MOX_SESSION_EVENT_TYPE_LATENCY
     */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_LATENCY_PACKET_NUM_THRESHOLD,

    /**
     * @brief MOX session event min latency enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_MONITOR_MOX_SESSION_EVENT_ATTR_TYPE == SAI_MONITOR_MOX_SESSION_EVENT_TYPE_LATENCY
     */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_MIN_LATENCY_ENABLE,

    /**
     * @brief MOX session event max latency enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_MONITOR_MOX_SESSION_EVENT_ATTR_TYPE == SAI_MONITOR_MOX_SESSION_EVENT_TYPE_LATENCY
     */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_MAX_LATENCY_ENBALE,

    /**
     * @brief End of attributes
     */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_END,

    /** Custom range base value */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_MONITOR_MOX_SESSION_EVENT_ATTR_CUSTOM_RANGE_END

} sai_monitor_mox_session_event_attr_t;

/**
 * @brief Support 8 latency threshold levels
 */
#define SAI_MONITOR_LATENCY_THRD_LEVEL 8
#define SAI_MONITOR_MICROBURST_THRD_LEVEL 8

/**
 * @brief Monitor event state
 */
typedef enum _sai_monitor_event_state_t
{
    /** Monitor event clear */
    SAI_MONITOR_EVENT_STATE_CLEAR,

    /** Monitor event occur */
    SAI_MONITOR_EVENT_STATE_OCCUR

} sai_monitor_event_state_t;

/**
 * @brief Micro burst event
 */
typedef struct _sai_monitor_mburst_stats_t
{
    /** Buffer monitor micro burst message */
    sai_object_id_t buffer_monitor_microburst_port;
    sai_uint32_t buffer_monitor_microburst_threshold_cnt[8];

} sai_monitor_mburst_stats_t;

/**
 * @brief Buffer monitor event
 */
typedef struct _sai_monitor_buffer_event_t
{
    /** Buffer monitor event message */
    sai_object_id_t buffer_monitor_event_port;
    sai_uint32_t buffer_monitor_event_total_cnt;
    sai_uint32_t buffer_monitor_event_port_unicast_cnt;
    sai_uint32_t buffer_monitor_event_port_multicast_cnt;
    sai_uint8_t buffer_monitor_event_state;
} sai_monitor_buffer_event_t;

/**
 * @brief Buffer_monitor_stats_direction
 */
typedef enum _sai_buffer_monitor_stats_direction_t
{
    SAI_BUFFER_MONITOR_STATS_DIRECTION_INGRESS,
    SAI_BUFFER_MONITOR_STATS_DIRECTION_EGRESS,

} sai_buffer_monitor_stats_direction_t;

/**
 * @brief Buffer monitor stats
 */
typedef struct _sai_monitor_buffer_stats_t
{
    /** Buffer monitor stats message */
    sai_object_id_t buffer_monitor_stats_port;

    /** Direction */
    sai_uint32_t buffer_monitor_stats_direction;

    sai_uint32_t buffer_monitor_stats_port_cnt;
} sai_monitor_buffer_stats_t;

/**
 * @brief Buffer latency event
 */
typedef struct _sai_monitor_latency_event_t
{
    /** Latency monitor event message */
    sai_object_id_t latency_monitor_event_port;
    sai_uint64_t latency_monitor_event_latency;
    sai_uint8_t  latency_monitor_event_level;
    sai_uint8_t  latency_monitor_event_state;
    sai_uint32_t  latency_monitor_event_source_port;
} sai_monitor_latency_event_t;

/**
 * @brief Buffer monitor stats
 */
typedef struct _sai_monitor_latency_stats_t
{
    /** Latency monitor stats message */
    sai_object_id_t latency_monitor_stats_port;
    sai_uint32_t latency_monitor_stats_level_cnt[8];
} sai_monitor_latency_stats_t;

/**
 * @brief Buffer_monitor_message_type
 */
typedef enum _sai_buffer_monitor_message_type_t
{
    SAI_BUFFER_MONITOR_MESSAGE_TYPE_EVENT_MESSAGE,
    SAI_BUFFER_MONITOR_MESSAGE_TYPE_STATS_MESSAGE,
    SAI_BUFFER_MONITOR_MESSAGE_TYPE_MICORBURST_STATS_MESSAGE,

} sai_buffer_monitor_message_type_t;

/**
 * @brief Buffer_monitor_message_type
 */
typedef enum _sai_buffer_monitor_based_on_type_t
{
    SAI_BUFFER_MONITOR_BASED_ON_TYPE_PORT,
    SAI_BUFFER_MONITOR_BASED_ON_TYPE_TOTAL,

} sai_buffer_monitor_based_on_type_t;

/**
 * @extraparam sai_buffer_monitor_message_type_t buffer_monitor_message_type
 */
typedef union _sai_monitor_buffer_data_t
{
    /**
     * @brief Buffer event
     *
     * @validonly buffer_monitor_message_type == SAI_BUFFER_MONITOR_MESSAGE_TYPE_EVENT_MESSAGE
     */
    sai_monitor_buffer_event_t buffer_event;

    /**
     * @brief Buffer stats
     *
     * @validonly buffer_monitor_message_type == SAI_BUFFER_MONITOR_MESSAGE_TYPE_STATS_MESSAGE
     */
    sai_monitor_buffer_stats_t buffer_stats;

    /**
     * @brief Micro burst stats
     *
     * @validonly buffer_monitor_message_type == SAI_BUFFER_MONITOR_MESSAGE_TYPE_MICORBURST_STATS_MESSAGE
     */
    sai_monitor_mburst_stats_t microburst_stats;
} sai_monitor_buffer_data_t;

/**
 * @brief Buffer monitor notification data
 */
typedef struct _sai_monitor_buffer_notification_data_t
{
    /**
     * @brief Buffer monitor id.
     *
     * @objects SAI_OBJECT_TYPE_MONITOR_BUFFER_MONITOR
     */
    sai_object_id_t monitor_buffer_monitor_id;

    /** Message type */
    sai_buffer_monitor_message_type_t buffer_monitor_message_type;

    /** Based on type */
    sai_buffer_monitor_based_on_type_t buffer_monitor_based_on_type;

    /**
     * @brief Buffer monitor data.
     *
     * @passparam buffer_monitor_message_type
     */
    sai_monitor_buffer_data_t u;

} sai_monitor_buffer_notification_data_t;

/**
 * @brief Latency_monitor_message_type
 */
typedef enum _sai_latency_monitor_message_type_t
{
    SAI_LATENCY_MONITOR_MESSAGE_TYPE_EVENT_MESSAGE,
    SAI_LATENCY_MONITOR_MESSAGE_TYPE_STATS_MESSAGE,

} sai_latency_monitor_message_type_t;

/**
 * @extraparam sai_latency_monitor_message_type_t latency_monitor_message_type
 */
typedef union _sai_monitor_latency_data_t
{
    /**
     * @brief Latency event
     *
     * @validonly latency_monitor_message_type == SAI_LATENCY_MONITOR_MESSAGE_TYPE_EVENT_MESSAGE
     */
    sai_monitor_latency_event_t latency_event;

    /**
     * @brief Latency stats
     *
     * @validonly latency_monitor_message_type == SAI_LATENCY_MONITOR_MESSAGE_TYPE_STATS_MESSAGE
     */
    sai_monitor_latency_stats_t latency_stats;
} sai_monitor_latency_data_t;

/**
 * @brief Latency monitor notification data
 */
typedef struct _sai_monitor_latency_notification_data_t
{
    /**
     * @brief Latency monitor id.
     *
     * @objects SAI_OBJECT_TYPE_MONITOR_LATENCY_MONITOR
     */
    sai_object_id_t monitor_latency_monitor_id;

    sai_latency_monitor_message_type_t latency_monitor_message_type;

    /**
     * @brief Latency monitor data.
     *
     * @passparam latency_monitor_message_type
     */
    sai_monitor_latency_data_t u;

} sai_monitor_latency_notification_data_t;

typedef struct _sai_monitor_mox_session_data_info_t
{
    uint16_t drop_reason1;

    uint16_t drop_reason2;

    uint16_t drop_pkt_cnt1;

    uint16_t drop_pkt_cnt2;

    uint8_t  queue_id;

    uint32_t min_latency;

    uint32_t max_latency;

    uint32_t burst_cnt;

    uint32_t latency_cnt;
} sai_monitor_mox_session_data_info_t;

typedef struct _sai_monitor_mox_session_key_info_t
{
    uint32_t gport;

    sai_ip_address_t ipsa;

    sai_ip_address_t ipda;

    uint16_t ip_protocol;

    uint16_t l4_src_port;

    uint16_t l4_dst_port;

    uint16_t vlan_id;

    uint32_t vrfid;

    uint32_t vni;

} sai_monitor_mox_session_key_info_t;

/**
 * @brief MOX session notification data
 */
typedef struct _sai_monitor_mox_session_notification_data_t
{
    /**
     * @brief MOX session id.
     *
     * @objects SAI_OBJECT_TYPE_MONITOR_MOX_SESSION
     */
    sai_object_id_t monitor_mox_session_id;

    /** MOX Session type */
    sai_monitor_mox_session_type_t mox_session_type;

    sai_monitor_mox_session_key_info_t mox_session_key_info;

    sai_monitor_mox_session_data_info_t mox_session_data_info;

} sai_monitor_mox_session_notification_data_t;

/**
 * @brief MONITOR BUFFER notifications
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Pointer to monitor buffer notification data array
 */
typedef void (*sai_monitor_buffer_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_monitor_buffer_notification_data_t *data);

/**
 * @brief Create buffer monitor
 *
 * @param[out] monitor_buffer_monitor_id Buffer monitor id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_monitor_buffer_monitor_fn)(
        _Out_ sai_object_id_t *monitor_buffer_monitor_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove buffer monitor
 *
 * @param[in] monitor_buffer_monitor_id Buffer monitor id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_monitor_buffer_monitor_fn)(
        _In_ sai_object_id_t monitor_buffer_monitor_id);

/**
 * @brief Set monitor attribute
 *
 * @param[in] monitor_buffer_monitor_id Buffer monitor id
 * @param[in] attr Attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_monitor_buffer_monitor_attribute_fn)(
        _In_ sai_object_id_t monitor_buffer_monitor_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get monitor attribute
 *
 * @param[in] monitor_buffer_monitor_id Buffer monitor id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_monitor_buffer_monitor_attribute_fn)(
        _In_ sai_object_id_t monitor_buffer_monitor_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief MONITOR LATENCY notifications
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Pointer to latency monitor notification data array
 */
typedef void (*sai_monitor_latency_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_monitor_latency_notification_data_t *data);

/**
 * @brief Create latency monitor
 *
 * @param[out] monitor_latency_monitor_id Latency monitor id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_monitor_latency_monitor_fn)(
        _Out_ sai_object_id_t *monitor_latency_monitor_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove monitor
 *
 * @param[in] monitor_latency_monitor_id Latency monitor id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_monitor_latency_monitor_fn)(
        _In_ sai_object_id_t monitor_latency_monitor_id);

/**
 * @brief Set monitor attribute
 *
 * @param[in] monitor_latency_monitor_id Latency monitor id
 * @param[in] attr Attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_monitor_latency_monitor_attribute_fn)(
        _In_ sai_object_id_t monitor_latency_monitor_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get monitor attribute
 *
 * @param[in] monitor_latency_monitor_id Latency monitor id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_monitor_latency_monitor_attribute_fn)(
        _In_ sai_object_id_t monitor_latency_monitor_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief MONITOR MOX session notifications
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Pointer to monitor MOX session notification data array
 */
typedef void (*sai_monitor_mox_session_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_monitor_mox_session_notification_data_t *data);

/**
 * @brief Create MOX session
 *
 * @param[out] monitor_mox_session_id Monitor MOX session id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_monitor_mox_session_fn)(
        _Out_ sai_object_id_t *monitor_mox_session_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove MOX session
 *
 * @param[in] monitor_mox_session_id Monitor MOX session id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_monitor_mox_session_fn)(
        _In_ sai_object_id_t monitor_mox_session_id);

/**
 * @brief Set MOX session attribute
 *
 * @param[in] monitor_mox_session_id Monitor MOX session id
 * @param[in] attr Attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_monitor_mox_session_attribute_fn)(
        _In_ sai_object_id_t monitor_mox_session_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get MOX session attribute
 *
 * @param[in] monitor_mox_session_id Monitor MOX session id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_monitor_mox_session_attribute_fn)(
        _In_ sai_object_id_t monitor_mox_session_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Create MOX session flow field
 *
 * @param[out] monitor_mox_session_flow_field_id Monitor MOX session flow field id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_monitor_mox_session_flow_field_fn)(
        _Out_ sai_object_id_t *monitor_mox_session_flow_field_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove MOX session flow field
 *
 * @param[in] monitor_mox_session_flow_field_id Monitor MOX session flow field id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_monitor_mox_session_flow_field_fn)(
        _In_ sai_object_id_t monitor_mox_session_flow_field_id);

/**
 * @brief Set MOX session flow field attribute
 *
 * @param[in] monitor_mox_session_flow_field_id Monitor MOX session flow field id
 * @param[in] attr Attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_monitor_mox_session_flow_field_attribute_fn)(
        _In_ sai_object_id_t monitor_mox_session_flow_field_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get MOX session flow field attribute
 *
 * @param[in] monitor_mox_session_flow_field_id Monitor MOX session flow field id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_monitor_mox_session_flow_field_attribute_fn)(
        _In_ sai_object_id_t monitor_mox_session_flow_field_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Create MOX session event
 *
 * @param[out] monitor_mox_session_event_id Monitor MOX session event id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_monitor_mox_session_event_fn)(
        _Out_ sai_object_id_t *monitor_mox_session_event_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove MOX session event
 *
 * @param[in] monitor_mox_session_event_id Monitor MOX session event id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_monitor_mox_session_event_fn)(
        _In_ sai_object_id_t monitor_mox_session_event_id);

/**
 * @brief Set MOX session event attribute
 *
 * @param[in] monitor_mox_session_event_id Monitor MOX session event id
 * @param[in] attr Attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_monitor_mox_session_event_attribute_fn)(
        _In_ sai_object_id_t monitor_mox_session_event_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get MOX session event attribute
 *
 * @param[in] monitor_mox_session_event_id Monitor MOX session event id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_monitor_mox_session_event_attribute_fn)(
        _In_ sai_object_id_t monitor_mox_session_event_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief MONITOR API
 */
typedef struct _sai_monitor_api_t
{
    sai_create_monitor_buffer_monitor_fn                          create_monitor_buffer_monitor;
    sai_remove_monitor_buffer_monitor_fn                          remove_monitor_buffer_monitor;
    sai_set_monitor_buffer_monitor_attribute_fn                   set_monitor_buffer_monitor_attribute;
    sai_get_monitor_buffer_monitor_attribute_fn                   get_monitor_buffer_monitor_attribute;
    sai_create_monitor_latency_monitor_fn                         create_monitor_latency_monitor;
    sai_remove_monitor_latency_monitor_fn                         remove_monitor_latency_monitor;
    sai_set_monitor_latency_monitor_attribute_fn                  set_monitor_latency_monitor_attribute;
    sai_get_monitor_latency_monitor_attribute_fn                  get_monitor_latency_monitor_attribute;
    sai_create_monitor_mox_session_fn                             create_monitor_mox_session;
    sai_remove_monitor_mox_session_fn                             remove_monitor_mox_session;
    sai_set_monitor_mox_session_attribute_fn                      set_monitor_mox_session_attribute;
    sai_get_monitor_mox_session_attribute_fn                      get_monitor_mox_session_attribute;
    sai_create_monitor_mox_session_flow_field_fn                  create_monitor_mox_session_flow_field;
    sai_remove_monitor_mox_session_flow_field_fn                  remove_monitor_mox_session_flow_field;
    sai_set_monitor_mox_session_flow_field_attribute_fn           set_monitor_mox_session_flow_field_attribute;
    sai_get_monitor_mox_session_flow_field_attribute_fn           get_monitor_mox_session_flow_field_attribute;
    sai_create_monitor_mox_session_event_fn                       create_monitor_mox_session_event;
    sai_remove_monitor_mox_session_event_fn                       remove_monitor_mox_session_event;
    sai_set_monitor_mox_session_event_attribute_fn                set_monitor_mox_session_event_attribute;
    sai_get_monitor_mox_session_event_attribute_fn                get_monitor_mox_session_event_attribute;

} sai_monitor_api_t;

/**
 * @}
 */
#endif /** __SAIEXPERIMENTALMONITOR_H_ */
